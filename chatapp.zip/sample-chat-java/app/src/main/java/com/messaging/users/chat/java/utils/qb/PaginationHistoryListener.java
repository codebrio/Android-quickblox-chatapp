package com.messaging.users.chat.java.utils.qb;

public interface PaginationHistoryListener {
    void downloadMore();
}