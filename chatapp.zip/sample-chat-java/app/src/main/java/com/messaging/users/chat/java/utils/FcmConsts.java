package com.messaging.users.chat.java.utils;

public interface FcmConsts {
    String EXTRA_FCM_MESSAGE = "message";
    String ACTION_NEW_FCM_EVENT = "new-push-event";
}