package com.example.sample.chat.java.utils.qb;

public interface PaginationHistoryListener {
    void downloadMore();
}